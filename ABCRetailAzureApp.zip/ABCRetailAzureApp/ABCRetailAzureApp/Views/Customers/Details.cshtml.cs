using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ABCRetailAzureApp.Views.Customers
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
