using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ABCRetailAzureApp.Views.Orders
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
