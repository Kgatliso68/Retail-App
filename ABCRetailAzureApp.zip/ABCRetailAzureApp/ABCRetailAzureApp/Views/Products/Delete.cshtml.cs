using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ABCRetailAzureApp.Views.Products
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
