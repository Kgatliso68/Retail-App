using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ABCRetailAzureApp.Views.Products
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
