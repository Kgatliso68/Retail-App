﻿namespace ABCRetailAzureApp.Models
{
    public enum OrderStatus
    {
        Pending,
        Confirmed,
        PaymentProcessing,
        Shipped,
        Delivered,
        Cancelled
    }
}